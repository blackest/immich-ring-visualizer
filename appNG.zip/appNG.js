﻿(function () {
  "use strict";

  // Legacy compatibility stub.
  // The active app entry point is bootstrapNG.js.
  // This file is intentionally not the runtime bootstrap anymore.
  window.AppNG = window.AppNG || {};
  window.AppNG.legacy = {
    name: "appNG.js",
    status: "legacy stub",
    note: "Use bootstrapNG.js as the active entry point.",
  };
})();
